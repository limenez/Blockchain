# DigitalInnovationOne-Aula03

Repositório de código para a Aula 03 - Sistema de votação baseado em Ethereum

## Tópicos abordados nesse projeto

* Smart Contract
* Contract ABI - Application Binary Interface
* Servidor web JavaScript
* HTML interface
* Deploy em ambiente local - Ganache
* Deploy em ambiente de teste - Testnet
